#!/usr/bin/perl

%h=();
$s1="interface=eth0";
$s2="onboot=yes";

($k,$v)=split("=",$s1);
$h{$k}=$v;
($k,$v)=split("=",$s2);
$h{$k}=$v;
foreach(sort keys(%h)){
	print "$_\t $h{$_}\n";
}

@r=sort(("zsh","csh","ash"));
print "@r\n";

