#!/usr/bin/perl
sub display{
	($r1)=@_;
	%hv=%$r1; # de-reference
	foreach(keys(%hv)){
		print "$_\t $hv{$_}\n";
	}
	print "\nExit from display block\n";
}

%h=("fstype"=>"xfs","fmount"=>"/mnt","fsize"=>"16TB");

display(\%h);
