#!/usr/bin/perl
my $app="flask";
sub display{
	my $port=5000;
	print "$app running port:$port\n";
}
print "A. Before calling display function:$port\n";
display(); # functionCall
print "\nB.After function Call: $port\n";
