#!/usr/bin/perl
sub f1{
	$v1=10; # global 
	my $v2=20;
	my($v3,$v4)=(30,40); # (my $v3, my $my)=(30,40);
	local $v5=50;
	f2(); # nested function call
}
sub f2{
	print "\$v1=$v1\t \$v2=$v2\n\$v3=$v3\n\$v4=$v4\n";
	print "\$v5=$v5\n";
}
f1();
print "from main section\n";
print "\$v1=$v1\t \$v2=$v2\n\$v3=$v3\n\$v4=$v4\n";
print "\$v5=$v5\n";
