#!/usr/bin/perl

$var="programming python java languages";

if($var =~ /(java).(python)/){
	print "OK\n";
}else{
	print "Not-Matched\n";	#=>Not-Matched 
}		
	
