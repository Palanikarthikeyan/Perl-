#!/usr/bin/perl
$a=10;

$r1=\$a;
$r2=\$r1;
print "$r2\n";
print ref($r2),"\n";
print "$$r2\n";
print "$$$r2\n";
print "\n----\n";
@b=(10,20,30);

$r1=\@b;
$r2=\$r1;
print ref($r2),"\n";
print $$r2,"\n";
print "@$$r2\n";
print "\n----\n";
%c=(K=>"V1","Kx"=>"V2");
$r1=\%c;
$r2=\$r1;
print ref($r2),"\n";
print $$r2,"\n";
%h=%$$r2;
foreach(keys(%h)){
	print "$_\t $h{$_}\n";
}
