#!/usr/bin/perl

$var="Apr 20 16:05:01 krosumlabs CRON[7424]: pam_unix(cron:session): session opened for user root by (uid=0)";

if($var =~ /[0-9]+|[A-Z]+|[^a-zA-Z0-9\s]+/){
	print "$var\n";
}

