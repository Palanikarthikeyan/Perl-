#!/usr/bin/perl
%h=("K1"=>"V1");
@a=();
push(@a,%h);
(%hv)=@a;
print @a,"\n";
print %hv,"\n";
