#!/usr/bin/perl
sub display{

	print "@_\t total no.of args:",scalar(@_),"\n";
}




%h=("fstype"=>"xfs","fmount"=>"/mnt","fsize"=>"16TB");

display(%h);
sleep 2;
display(\%h);
