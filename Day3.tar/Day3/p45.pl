#!/usr/bin/perl
 print "Enter any two digits:";
 
 chomp($n=<>);

 if($n =~ /^[0-9]{2}$/){
		print "n value is:$n\n";
 }else{
		print "Sorry invalid format\n";
 }
 
