#!/usr/bin/perl
@a=("D1","D2","D3");

%b=("K1"=>"V1","K2"=>123,"K3"=>1.34);

@arr=%b;
print "@arr\n";
print "\n";
%h=@a;
print %h;
print "\n";
