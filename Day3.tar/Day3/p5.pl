#!/usr/bin/perl

if(scalar(@ARGV) != 1){
	print "Usage:Commandline args - will accept single argument\n";
	print "$0 <filename>\n";
	exit;
}
if($0 eq $ARGV[0]){
	print "Usage:Commandline argument input file is same as script file\n";
	exit;
}

#open(FH,$ARGV[0]) or die($!);

$fname=$ARGV[0];
open(FH,$fname) or die($!);
while(<FH>){
	if($. >2 && $. <8){
	  print "$.  $_";
        }
}
close(FH);
