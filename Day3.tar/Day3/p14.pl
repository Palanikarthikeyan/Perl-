#!/usr/bin/perl
sub display{
	print "List of perl script files:\n";
	system("ls -l *.pl");
	$count=`ls -l *.pl|wc -l`;
	print "Total no.of perl script files:$count\n";
	process(); # nested function/subroutineCall
	print "Exit from display block\n";
}
sub process{
	print "Current process details:-\n";
	system("ps -f");
	print "Exit from process block\n";
}

print "This main script - section\n";
sleep 2;
display();
print "Exit from $0 script file\n";
