#!/usr/bin/perl

while(<>){ # interface to keyboard
  
   #if($_ =~ /^sales/i){ # i - ignoring pattern case 
	
    #if($_ =~ /^\s/){

	if(m/^\s/){ # $_ =~ /^\s/ <==
		print "matched - $_";
   }else{
		print "Not-matched\n";
  }
}
 
