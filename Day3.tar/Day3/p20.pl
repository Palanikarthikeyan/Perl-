#!/usr/bin/perl
sub list_of_files{
	($v1,$v2,$v3)=@_;
	@a=@$v1; # de-reference
	print "@a\n\n";
	@c=@$v3; # de-reference 
	print "@c\n";
}

@F=("p1.log","p2.log","test.java");

@counters=(100,23,45,240,500);

@hosts=("host01","host02","host03","host04");

list_of_files(\@F,\@counters,\@hosts);
