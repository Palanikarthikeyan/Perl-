#!/usr/bin/perl
open(FH,"emp.csv") or die($!);

while(<FH>){
	#if($_ =~ /sales/){

	if($_ =~ /00$/){
		print "$_";
	}
}
close(FH);

# grep sales emp.csv
