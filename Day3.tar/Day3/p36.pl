#!/usr/bin/perl

@a=(`ps -e`);

print scalar(@a),"\n";

foreach((@a)){
	if($_ =~ /d$/){
		print "$_";
	}
}

