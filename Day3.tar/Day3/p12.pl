#!/usr/bin/perl
print "This is main script code\n";
sub f1{
	print "This is f1 block\n";
	f2(); # nested call
	print "Exit from f1 block\n";
}
sub f2(){
	print "This is f2 block\n";
	print "List of files:-\n";
	print "Exit from f2 block\n";
}
f1(); # simple function/subroutine call
sleep 2;
print "\nExit from $0  script\n";
