#!/usr/bin/perl
open(FH,"emp.csv") or die($!);

while(<FH>){
	$_ =~ s/sales/ADMIN/;
	print "$. $_";
}
close(FH);
