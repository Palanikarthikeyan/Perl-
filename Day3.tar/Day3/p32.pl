#!/usr/bin/perl
while(<>){ # interface to keyboard
  
   if($_ =~ /sales/i){ # i - ignoring pattern case 
		print "matched - $_";
   }else{
		print "Not-matched\n";
  }
}
 
