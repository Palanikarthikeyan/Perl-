#!/usr/bin/perl

print "Enter some text:";
chomp($ivar=<>);

#if ($ivar =~ /sales$/){ # line ends with sales


if ($ivar =~ /\s$/){ # line ends with space
	print "$ivar\n";
}else{
	print "Not-matched\n";
}
