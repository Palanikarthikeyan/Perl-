#!/usr/bin/perl
while(<>){ # interface to keyboard
  
   if($_ =~ /sales/){
		print "matched - $_";
   }else{
		print "Not-matched\n";
  }
}
 
