#!/usr/bin/perl


open(FH,"emp.csv") or die($!);
open(WH,">r1.log") or die($!);
while(<FH>){
	if ($_ =~ /sales/){
		$_ =~ s/sales/ADMIN/;
		print "$. $_"; # display to monitor
		print WH "$. $_"; # writing data to FILE
	}
}
close(FH);
close(WH);
