#!/usr/bin/perl
sub display{
	($v1,$v2,$v3,$v4)=@_; # from array to list 
	# $v1=$_[0];  # index by index
	# $v2=$_[1];
	# $v3=$_[2];
	print "$v1\n$v2\t$v3\n";

	$en=shift(@_);
	$eid=shift(@_);
	print "Emp name:$en\t Emp id:$eid\n";
	print "Emp other details:- @_\n";
	print "Exit from display block\n";
}
$ename="Mr.arun";
display($ename,"e123","sales",12455.23);
