#!/usr/bin/perl

 $var="101,raj,sales,pune,Sales,1000,sales-details\n";

 $var =~ s/sales/prod/gi;

 print($var)
