#!/usr/bin/perl
$a=10;
$r1=\$a;
print(ref($r1));
print("\n");

@b=();
$r2=\@b;
print(ref($r2));
print("\n");

%h=();
$r3=\%h;
print(ref($r3));
print("\n");

#print(ref($a),ref(@b),ref(%h),"\n"); ->undef
