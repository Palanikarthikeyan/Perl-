#!/usr/bin/perl

$a=10;
@b=(100,200,"d1");
%c=(K1=>"V1",K2=>"V2",K3=>"V3");

# creating reference 
$r1=\$a;
$r2=\@b;
$r3=\%c;
if(ref($r1) eq "SCALAR"){
	print("$$r1\n");
}elsif(ref($r1) eq "ARRAY"){
	@a=@$r1;
	print("@a\n");
}elsif(ref($r1) eq "HASH"){
	%h=%$r1;
	foreach(keys(%h)){
		print "$_\t $h{$_}\n";
	}
}
