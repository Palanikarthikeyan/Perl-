#!/usr/bin/perl
open(FH,"p1.log") or die($!);

while(<FH>){
	if(m/^$/){
		next;
	}else{
		print "$_"; # non-empty line content
	}
}
close(FH);
