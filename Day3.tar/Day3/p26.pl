#!/usr/bin/perl
sub f1{
	my $v=100;
	my @arr=("D1","D2","D3");
	my %h=("K1"=>"V1","K2"=>"V2");
	return \%h;
}
$r=f1();
%h=%$r;
print keys(%h);

