#!/usr/bin/perl
for $v (10,20,30,40,50){
	print "$v\n";
}
print("\n");

for(100,200,300,400,500){
	print "$_\n";
} 
