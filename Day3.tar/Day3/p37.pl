#!/usr/bin/perl
while($var=<>){
	chomp($var);
	if($var =~ /^sales$/){
		print "matched - $var\n";
	}else{
		print "Not-matched\n";
	}
}
