#!/usr/bin/perl

 $r=`uptime`;

 # delete all the space 

 $r =~ s/\s//g;
 
 print "$r\n";
