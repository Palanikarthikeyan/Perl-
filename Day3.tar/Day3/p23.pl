#!/usr/bin/perl
$app="flask";
sub display{
	$port=5000;
	print "$app running port:$port\n";
}
print "A. Before calling display function:$port\n";
display(); # functionCall
print "\nB.After function Call: $port\n";
