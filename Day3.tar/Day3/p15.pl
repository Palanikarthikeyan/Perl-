#!/usr/bin/perl
sub f1{
	print "A. @_\n";
	print "B. total no.of args:",scalar(@_),"\n";
	print "This is f1 block\n";
}

f1(); # simple functionCall - there is no arguments
sleep 2;

f1(10,1.34,"data"); # function call with args
sleep 2;
print("\n");
$a=100;
@b=("D1","D2","D3");
%c=(app=>"TestApp",port=>1234,service=>"serviceName.service");

f1($a,@b,%c);  # functionCall with args

@A1=(100,200,300);
@A2=(1.34,2.34,0.23);

f1(@A1,@A2); # functioncall with args 
f1(\@A1,\@A2);
