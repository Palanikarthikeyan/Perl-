#!/usr/bin/perl
open(FH,"p1.log") or die($!);

while(<FH>){
	unless(m/^$/){
		print "$_"; # non-empty line content
	}
}
close(FH);
