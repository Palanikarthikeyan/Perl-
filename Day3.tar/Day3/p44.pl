#!/usr/bin/perl

@result=(`ps -e`);

foreach((@result)){
	if($_ =~ /^\s{3,}[0-9]{2,}/){
		print $_;
	}
}
