#!/usr/bin/perl


 $var="101,raj,sales,pune,1000\n";

 $var =~ s/sales.//; # delete a sales word
 print($var)
