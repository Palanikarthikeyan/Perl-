#!/usr/bin/perl
%h=("interface" => "eth0","onboot" =>"yes","doamin"=>"example.com","k1" =>"v1");

@K=keys(%h);

print "\@K -  @K\n";

@sa=sort(@K);

print "\@sa - @sa\n";

foreach(@sa){
	print "$_\n";
}
print "\n";
foreach(sort(keys(%h))){
	print "$_\n";
}
