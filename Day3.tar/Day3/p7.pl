#!/usr/bin/perl
$a=10;
@b=(100,200,"d1");
%c=(K1=>"V1",K2=>"V2",K3=>"V3");

# creating reference 
$r1=\$a;
$r2=\@b;
$r3=\%c;

print("$r1\t $r2\t $r3\n");

print("$$r1\n");

$v=$$r1; # de-reference 
print("$v\n");

@v=@$r2; # de-reference

print("@v\t @$r2\n");

%h=%$r3; # de-reference
foreach(keys(%h)){
	print "$_\t $h{$_}\n";
}
