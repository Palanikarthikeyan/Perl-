#!/usr/bin/perl
open(FH,"p1.log") or die($!);

while($v=<FH>){
	print "$v";
}
close(FH);
print("\n");

open(FH,"p1.log") or die($!);
while(<FH>){
	print "$_";
}
close(FH);
print("\n");
open(FH,"p1.log") or die($!);
while(<FH>){
	print;
}
close(FH);
