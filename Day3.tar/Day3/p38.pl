#!/usr/bin/perl
while(<>){
	#if($_ =~ /^[159].*[0sr]$/){

	if($_ =~ /^[A-Z].*[a-z]$/){
		print "$_";
	}
}
