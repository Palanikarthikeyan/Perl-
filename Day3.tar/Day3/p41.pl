#!/usr/bin/perl
while($var=<>){
	chomp($var);
	#if($var =~ /^[A-Za-z].*[a-z]$|\s$/){
	
	if($var =~ /python|perl|java/){
		print "Matched - $var\n";
	}
}
