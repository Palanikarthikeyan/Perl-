#!/usr/bin/perl
sub f1{
	my $port=1234;
	return $port;
}
sub f2{
	my $service="apache2";
	return $service;
}
sub f3{
	print "Enter your login name:";
	chomp(my $name=<>);
	if($name eq "root"){
		return 1;
	}else{
		return 0;
	}
}
$rv=f1();
print "\$rv value is:$rv\n";

$s=f2();
print "\$s value is:$s\n";

$r=f3();
if($r){
	print "Yes - Success\n";
}else{
	print "sorry - login is failed\n";
}
