#!/usr/bin/perl
$v=150;
$b=123.45;

$t=$v+$b;
print("Total:$t\n");
$m=$v*$b;
print("Mult:$m\n");
print("div:",$v/5,"\n");
print(2**3);
print("\n");
