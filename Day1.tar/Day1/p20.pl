#!/usr/bin/perl
print "Enter a port number:";
chomp($port=<>);

if($port >500 && $port <600){
	$app="testApp";
}else{
	print "Sorry port number:$port is not valid range\n";
	exit; # exit from perl script execution
}
print "Port Number:$port\t AppName:$app\n";
