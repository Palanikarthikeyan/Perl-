#!/usr/bin/perl
print "Enter N value:";
chomp($n=<>);

if($n >10){
	print "True block - $n >10\n";
}else{
	print "False block - $n <10\n";
}
print("\n--unless--\n");
unless($n >10){
	print "True block - $n >10\n";
}else{
	print "False block - $n <10\n";
}
