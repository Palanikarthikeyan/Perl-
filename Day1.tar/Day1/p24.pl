#!/usr/bin/perl
$name=`whoami`;
print $name;

chomp($name);
print($name);
