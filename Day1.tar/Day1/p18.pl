#!/usr/bin/perl
print "Enter a login name:";
chomp($name=<>);

if($name eq "root")
{
	print "Login name is:root\n"
}else{
	print "Login is failed\n";
}
