#!/usr/bin/perl
print "Enter a port number:";
chomp ($port=<>);

if($port >500){
	print("matched-1\n");
}elsif($port == 450){
	print("matched-2\n");
}elsif($port <400){
	print("Matched-3\n");
}else{
	print("Not-matched\n");
}
