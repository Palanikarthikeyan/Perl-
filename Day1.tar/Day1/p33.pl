#!/usr/bin/perl
$i=0;
while($i < 5){
	print "i value is:$i\n";
	#$i=$i+1;
	#$i++;
	$i+=1; # $i=$i+1
}
print "End of the script\n";
