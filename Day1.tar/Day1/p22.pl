#!/usr/bin/perl
print("Current process details:-");
system("ps -f");
print("\n"); # empty line
$process=`ps -f`;
print($process);
print("End of the script\n");
