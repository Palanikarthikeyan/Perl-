#!/usr/bin/perl
print "Enter a shell name:";
chomp($var=<>);

if($var eq "bash"){
	$fname="/etc/bashrc";
}elsif($var eq "ksh" || $var eq "zsh"){
	$fname="/etc/kshrc";
}elsif($var eq "sh"){
	$fname="/etc/shrc";
}else{
	$var="/bin/nologin";
	$fname="/etc/profile";
}

print "Shell name:$var\t profile file:$fname\n";	
	
