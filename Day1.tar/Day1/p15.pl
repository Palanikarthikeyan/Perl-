#!/usr/bin/perl
print "Enter a partition name:";
chomp($p1=<>);
print "Enter $p1 Size:";
chomp($ps1=<>);
print "Enter another partition name:";
chomp($p2=<>);
print "Enter $p2 Size:";
chomp($ps2=<>);
$total=$ps1+$ps2;
print("
-------------------------------------
Partition Name:$p1	Size:$ps1 GB
--------------------------------------
Partition Name:$p2	Size:$ps2 GB
--------------------------------------
		Total   Size:$total GB
---------------------------------------\n");
