#!/usr/bin/perl

if(`ps -e|wc -l` >150){
	print("Total no.of process count is above 150\n");
}else{
	print("Total no.of process count is below 150\n");
	system("ps -e|wc -l");
}
