#!/usr/bin/perl
print "Enter a directory name:";
chomp($dname=<>);

if(-d $dname){
	print("directory file:$dname is already exists\n");
	print("$dname details:-\n");
	system("ls -ld $dname");
}else{
	system("mkdir $dname");
	print("$dname details:-\n");
	system("ls -ld $dname");
}
