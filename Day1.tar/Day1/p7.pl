#!/usr/bin/perl
print "Enter N value:";
$n=<>;
print $n;
chomp($n);
print $n;
