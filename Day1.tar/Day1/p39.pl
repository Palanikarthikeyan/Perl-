#!/usr/bin/perl
$c=5;
while($c < 10){
	print "c value is:$c\n";
	$c++;
}
print("\n"); # empty line
sleep(2);

$c=5;
until($c <10){
	print("True block\n");
	$c++;
}
print("\n");

$c=15;
until($c <10){ 
	print("True block\n");
	$c--;
}
