#!/usr/bin/perl
for($i=0;$i<5;$i++){
	print("Enter a name:");
	chomp($name=<>);
	if($name eq "admin" || $name eq "ADMIN"){
		print("Matched\n");
	}else{
		print("Not-Matched\n");
	}
}
