#!/usr/bin/perl
print "Enter a file name:";
chomp($fname=<>);

if (! -f $fname){
	print "File:$fname is not a reg.file\n";
}

