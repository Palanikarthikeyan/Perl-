#!/usr/bin/perl
$c=0;

while($c < 5){
	system("uptime");
	sleep(2);
$c++;
}
