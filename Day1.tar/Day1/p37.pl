#!/usr/bin/perl
for($i=0;$i<5;$i++){
	print("Enter a name:");
	chomp($name=<>);
	if($name eq "admin" || $name eq "ADMIN"){
		print("Matched\n");
		last; # exit from loop # last Vs exit
	}else{
		print("Not-Matched\n");
	}
}

print "Next section of code block\n";
print "Exit from script\n";
