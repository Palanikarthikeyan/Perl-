#!/usr/bin/perl
print "Enter a file system type:";
chomp($fstype=<>);
print "Enter $fstype file system Size:";
chomp($fsize=<>);
print "Enter a partition name:";
chomp($part=<>);
print "Enter a mount point:";
chomp($mount = <>);

print("File system details:-
-------------------------------------
File system type:$fstype\t Size:$fsize
Partition name:$part\n MountPoint:$mount
-------------------------------------\n");

