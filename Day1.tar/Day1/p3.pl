#!/usr/bin/perl
# file system details 
# ---------------------
# filesystem type; partition;mount point;size 

$fstype="xfs";
$fpart= "/dev/xvdb1";
$fmount ="/mnt";
$fsize = "2TB";
print($fstype);
print("\n");
print("$fstype\n");
print("File system type is:$fstype\n");
print("Partition name is:$fpart\n");
print("Mount point is:$fmount\n");
print("==>$Fstype\n");
