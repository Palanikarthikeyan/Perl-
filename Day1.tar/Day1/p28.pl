#!/usr/bin/perl
print "Enter a filename:";
chomp($fname=<>);
if(-e $fname){
  if(-f $fname){
	print "Yes file:$fname is a reg.file\n";
	system("ls -l $fname");
   }elsif(-d $fname){
	print "Yes file:$fname is a directory file\n";
	system("ls -ld $fname");
   }else{
	print "File:$fname is exists - not a reg/dir file\n";
  }
  }else{
	print("Sorry file:$fname is not exists\n");
	exit; # exit from script
}
