#!/usr/bin/perl
while(1){
	print "Enter a login name:";
	chomp($name=<>);
	if($name eq "root" || $name eq "admin"){
		print("Matched\n");
		last;
	}
}
