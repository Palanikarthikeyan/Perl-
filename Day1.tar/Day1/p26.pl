#!/usr/bin/perl
print "Enter a shell name:";
chomp($var=<>);
if($var eq "bash" || $var eq "ksh"){
	$fname="/etc/bashrc";
}elsif($var eq "sh"){
	$count=`ps -e|grep sh|wc -l`;
	if($count >5){
		print("Total no.of sh shell is above $count\n");
		$fname="/bin/shrc";
	}else{
		print("No.of shell is below 5\n");
		$fname="/bin/shrc";
	}
}else{
	$var="/bin/nologin";
	$fname="/etc/profile";
}

print("Shell name:$var\t file name:$fname\n");
