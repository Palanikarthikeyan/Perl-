#!/usr/bin/perl
print "ab" eq "ab","\n";
print "ab" eq "Ab";
print 560 >500,"\n";
print 600 <650,"\n";
print "root" eq "root","\n";
print 1001 == 1001,"\n";
print 1001 == 1002;
print "==>",("ab" eq "Ab") eq undef;
print "\n";
