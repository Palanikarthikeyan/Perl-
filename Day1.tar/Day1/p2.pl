#!/usr/bin/perl
print(45);
print("\nsample text\n");
print(1.34);
