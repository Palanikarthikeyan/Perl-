#!/usr/bin/perl
$s1="sample perl script\n";
$s2="sample python script";

print $s2;
print $s1; # \n  is last char
chomp($s1);
sleep 2;
print("\n--\n");
print $s1;
print $s2;

