#!/usr/bin/perl
$s="sample test data\n";
print($s);
print("\n"); # empty line
chomp($s); # remove \n chars 
print($s);
print("--\n");
