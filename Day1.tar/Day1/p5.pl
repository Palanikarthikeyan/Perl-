#!/usr/bin/perl

print "Enter a file name:";
$fname=<>; # interface to keyboard <STDIN>
print $fname; # display to monitor STDOUT
