#!/usr/bin/perl
print "Enter a file name:";
chomp($fname=<>);

unless (-f $fname){
	print "File:$fname is not a reg.file\n";
}

