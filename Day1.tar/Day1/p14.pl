#!/usr/bin/perl
print("Enter N value:");
chomp($n=<>);
print("$n+100\n");
print("Sum of $n+100 \n");
print("Sum of $n+100 value is:",$n+100,"\n");
