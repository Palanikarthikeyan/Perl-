#!/usr/bin/perl
for($i=0;$i<5;$i++){
	print("i value is:$i\n");
}
