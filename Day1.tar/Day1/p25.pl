#!/usr/bin/perl
$name=`whoami`;
chomp($name);
if( $name eq "root"){
	print "enter a package name:";
	chomp($pk=<>);
	$rv=system("rpm -q $pk");
	if($rv==-1){
		print "package name:$pk is already installed\n";
	}else{
		print "package $pk is not exists\n";
		$rv=system("yum -y install $pk");
		if($rv == 1){
			print("Ok-1\n");
		}elsif($rv == -1){
			print("OK-2\n");
		}else{
			print("Error\n");
		}	
	}
	
}else{
	print "Sorry your not a root user\n";
}

