#!/usr/bin/perl
print "Enter N value:";
$n=<>; # interface to keyboard
print("n value is:$n");
print "Enter M value:";
chomp($m=<>); # interface to keyboard & remove \n chars
chomp($n); # remove \n chars
print("\n");# empty line
print($n,$m);
