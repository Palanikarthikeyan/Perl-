#!/usr/bin/perl
$fname="/etc/passwd";
$ftype="ASCII/TEXT";
$size="4KB";
$user="root";
$perm="rw-rw-r--";

print("About file name:$fname\n");
print("$fname file type is:$ftype\n");
print("$fname file size:$size\n");
print("user name is:$user\n");
print("$fname file permission details:-\n$perm\n");
