#!/usr/bin/perl
print("server1\nserver2\nserver3\nserver4\nserver5\n");
print("\n");
print("server1
server2
server3
server4");
print("\n");
