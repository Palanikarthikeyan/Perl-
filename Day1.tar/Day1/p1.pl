#!/usr/bin/perl
print("this is sample perl script\n");
print("perl supports 3 types structs");
print("\n"); # empty line
print("1.scalar\n2.array\n3.hash\n");
sleep(3);
print "In perl function round symbols () is optional\n";
sleep 2;
print("End of the script\n");

