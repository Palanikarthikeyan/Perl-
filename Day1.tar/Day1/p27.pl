#!/usr/bin/perl
print "Enter a file name:";
chomp($fname=<>);

if(-f $fname){
	print "Yes file:$fname is reg.file\n";
}else{
	print "Sorry file:$fname is not a reg.file\n";
}
