$fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
print $fsinfo,"\n";
print $$fsinfo{fstype},"\n";
print $fsinfo->{fstype},"\n";
$fsinfo->{fstype}="xfs"; # we can modify existing structure
print $fsinfo->{fstype},"\n";
