use box;
$obj1=box::f1();
$obj1->f2("xfs"); # f2($obj1,"xfs") 

$rv1=$obj1->f3();

print "\$rv1:$rv1\n";

