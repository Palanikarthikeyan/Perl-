package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  return $fsinfo;
}

package main;
$r1=box::f1();
print "default fstype is:$r1->{fstype}\n";
$r1->{fstype}="xfs"; # we can modify existing key
print "fstype is:$r1->{fstype}\n\n";

$r2=box::f1();
print "default fstype is:$r2->{fstype}\n";
$r2->{fstype}="btrfs"; # we can modify existing key
print "fstype is:$r2->{fstype}\n";
