package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  print "\$fsinfo:$fsinfo\n\n";
  return $fsinfo;
}

package main;
$r1=box::f1();
print "\$r1:$r1\n\n";

$r2=box::f1();
print "\$r2:$r2\n";
