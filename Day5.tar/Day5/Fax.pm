package Fax;
sub new{
	($class,$a,$b)=@_;
	$r={};
	return bless($r,$class);
}
sub f1{
	print "B.@_\n";
}
package main;
#$obj=Fax::new(arg1,arg2); 

$obj=Fax->new(arg1,arg2); # new(Fax,arg1,arg2); # other programming -> obj=Fax(arg1,arg2,arg3,arg4,..argN);
$obj->f1();
