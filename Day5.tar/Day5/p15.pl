use Employee;

$obj1=Employee->new("arun","sales","1stJan");
$obj1->display();
$obj1->update("ADMIN");
print("Updated details:-\n");
$obj1->display();
print "\n";

$obj2=Employee->new("vijay","prod","2ndFeb");
$obj2->display();

$obj3=Employee->new("anu","HR","3rdMarch");
$obj3->display();

print("\n");
$obj1->display();
