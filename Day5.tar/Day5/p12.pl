use box;
$r1=box->f1("ocfs"); # f1(box,"ocfs")
$r1->f2("xfs"); # f2($r1,"xfs") 

$r2=box::f1();
$r2->f2("btrfs"); # f2($r2,"btrfs")
