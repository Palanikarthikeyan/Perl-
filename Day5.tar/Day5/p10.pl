package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  return $fsinfo;
}
sub f2{
	($r1,$v)=@_; # from array to list # $r1=shift(@_);
	print "default fstype is:$r1->{fstype}\n";
	$r1->{fstype}="$v"; # we can modify existing key
	print "fstype is:$r1->{fstype}\n";
}
package main;
$r1=box::f1();
#$r1->f2(); # we can't call - $r1 is not a blessed reference
box::f2($r1,"xfs");

$r2=box::f1();
box::f2($r2,"btrfs");
