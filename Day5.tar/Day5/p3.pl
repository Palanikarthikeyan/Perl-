package Box;
sub initialization{
	$h={"boxid"=>101,"boxname"=>B1};
	return bless($h);
}
sub f1{
	print "This is f1 block\n";
	print "\@_ = @_\n";
}
package main;
$obj1=Box::initialization();
print "\$obj1:$obj1\n";
$obj1->f1();
print("\n");
$obj2=Box::initialization();
print "\$obj2:$obj2\n";
$obj2->f1();
