package fax;
sub f1{
	$h={};
	print "A.",ref($h),"\n";
	bless($h);
	print "B.",ref($h),"\n";
}
f1();
