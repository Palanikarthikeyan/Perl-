use strict;
my $var=100;
print("$var\n");
print("$var\n");
