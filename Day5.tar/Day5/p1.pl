package One;
sub display{
        $h={};
	print "This is display block\t \$h=$h\n";
	return bless($h);
}
sub method1{
	print "method\n";
}

package main;
$rv1=One::display();
$rv2=One->display();
print "\$r1:$rv1\t \$r2:$rv2\n";
$rv1->method1();
