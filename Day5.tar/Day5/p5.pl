package box;
$fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
package main;
print $box::fsinfo,"\n";
print $$box::fsinfo{fstype},"\n";
print $box::fsinfo->{fstype},"\n";
$box::fsinfo->{fstype}="xfs"; # we can modify existing structure
print $box::fsinfo->{fstype},"\n";
