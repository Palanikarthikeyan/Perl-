package Emp;
sub new{
   $h={name=>"",dept=>"",dob =>""};
   return bless($h);
}
sub enrollment{
    ($r1,$en,$ed,$edob)=@_;
    
     $r1->{name}=$en;
     $r1->{dept}=$ed;
     $r1->{dob}=$edob;
     print "Enrollment is done!\n";
}
sub display{
    $r1=shift; # $r1=shift(@_);
    print "Employee details:-\n";
    print "---------------------\n";
    print "Emp name:$r1->{name}\tWorking dept:$r1->{dept}\n";
    print "$r1->{name} DOB is:$r1->{dob}\n";
}
sub update{
    ($r1,$ed)=@_;
    $r1->{dept}=$ed;   
    print "dept entry is updated\n";
}
1;
