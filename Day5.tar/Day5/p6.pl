package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  print "\$fsinfo:$fsinfo\n\n";
  return $fsinfo;
}
package main;
$r=box::f1();
print "\$r:$r\n";
