package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  return $fsinfo;
}

package main;
$r=box::f1();
print $$r{fstype},"\n";
print $r->{fstype},"\n";
$r->{fstype}="xfs"; # we can modify existing key
print $r->{fstype},"\n";
