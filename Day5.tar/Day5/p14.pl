use Emp;
$obj1=Emp::new();
$obj1->enrollment("Arun","sales","1st Jan");
$obj1->display();

$obj2=Emp::new();
$obj2->enrollment("leo","prod","2nd Feb");
$obj2->display();

$obj3=Emp::new();
$obj3->enrollment("anu","HR","3rd March");
$obj3->display();

$obj2->update("ADMIN");
print "Updated details:-\n";
$obj2->display();
