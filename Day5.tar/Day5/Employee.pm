package Employee;
sub new{
   ($class,$en,$ed,$edob)=@_;
   $h={name=>"",dept=>"",dob =>""};
   $h->{name}=$en;
   $h->{dept}=$ed;
   $h->{dob}=$edob;
   print "Enrollment is done!\n";
   return bless($h,$class);
}
sub display{
    $r1=shift; # $r1=shift(@_);
    print "Employee details:-\n";
    print "---------------------\n";
    print "Emp name:$r1->{name}\tWorking dept:$r1->{dept}\n";
    print "$r1->{name} DOB is:$r1->{dob}\n";
}
sub update{
    ($r1,$ed)=@_;
    $r1->{dept}=$ed;   
    print "dept entry is updated\n";
}
1;
