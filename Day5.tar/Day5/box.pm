package box;
sub f1{
  ($r1,$ft)=@_;
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  $fsinfo->{fstype}=$ft;
  return bless($fsinfo);
}
sub f2{
	($r1,$v)=@_; # from array to list # $r1=shift(@_);
	print "default fstype is:$r1->{fstype}\n";
	$r1->{fstype}="$v"; # we can modify existing key
	print "fstype is:$r1->{fstype}\n";
}
sub f3{
	$r=shift(@_);
	return $r->{fstype};
}
1;
