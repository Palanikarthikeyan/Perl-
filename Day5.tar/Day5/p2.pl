package Box;
sub initialization{
	print "This is constructor block\n";
	$h={};
	return bless($h,Box);
}
sub f1{
	print "This is non-constructor-1\n";
}
sub f2{
	print "This is non-constructor-2\n";
}
=begin
package main;
$obj=Box::initialization();
$obj->f1();
$obj->f2();
=cut
package main;
$r=Box::initialization();
Box::f1();
Box::f2();
