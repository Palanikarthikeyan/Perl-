package box;
sub f1{
  $fsinfo={fstype =>"ext4",fmount =>"/mnt",fpart => ""};
  return bless($fsinfo);
}
sub f2{
	($r1,$v)=@_; # from array to list # $r1=shift(@_);
	print "default fstype is:$r1->{fstype}\n";
	$r1->{fstype}="$v"; # we can modify existing key
	print "fstype is:$r1->{fstype}\n";
}
package main;
$r1=box::f1();
$r1->f2("xfs"); # f2($r1,"xfs") 

$r2=box::f1();
$r2->f2("btrfs"); # f2($r2,"btrfs")
