@sh=("/bin/bash","/bin/sh","/bin/ksh","/bin/tcsh","/bin/zsh");
$c=0;
for $v (@sh){
	$c++;
	print "$c - $v\n";
}
