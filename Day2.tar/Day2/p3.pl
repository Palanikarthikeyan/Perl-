
foreach $var (10,1.34,"data","p1.log","p2.log"){
	print "\$var value is:$var\n";
}
print ("\n"); # empty line

@fnames=("p1.log","p2.c","p1.py","/var/www/index.html");

foreach $var (@fnames){
	print("$var\n");
}
