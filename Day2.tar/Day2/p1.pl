$a=10;
$b=$a; 
print "$a\t $b\n";

@arr1=("D1",10,1.34);

@arr2=@arr1;

print "@arr1\t @arr2\n";

$c=@arr1;

print "\$c value:$c\n";

