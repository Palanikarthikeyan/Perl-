@emp=("101,raj,sales,pune,1000\n","102,leo,HR,bglore,2000\n","134,anu,prod,noida,3000\n","152,paul,sales,bglore,4000\n");

#@r=grep(/sales/,("raj,sales","sales,vijay","sales","prod","HR"));
@r=grep(/sales/,@emp);
print "@r\n";
=begin
@emp=("raj","leo","arun","paul","anu");

@r=grep(/arun/,@emp);

print "@r\n";
=cut
