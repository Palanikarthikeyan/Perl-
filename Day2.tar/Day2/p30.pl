open(FH,"emp.csv");
while($var=<FH>){
	print($var);
}
close(FH);
