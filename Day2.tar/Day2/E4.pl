#@pin_history=(); # empty array
open(WH,">>pin_history.log") or die($!);
$pin=1234;
$c=0;

while($c < 3){
	print "Enter a pin number:";
	chomp($p=<>);
	$c++;
	if($p == $pin){
		print "Success - pin is matched - $c\n";
		#push(@pin_history,"success - pin is matched - $c entered on ".`date`);
		print WH "success - pin is matched - $c entered on ".`date`;
		last; # exit from loop
	}else{
		print WH "failed - input pin number:$p - entered on ".`date`;
		#push(@pin_history,"failed - input pin number:$p - entered on ".`date`);
	}
}

if($pin != $p){
	print "Sorry your pin is blocked\n";
	#push(@pin_history,"Sorry your pin is blocked ".`date`)
	print WH "Sorry your pin is blocked ".`date`;
}
close(WH);
print "Wish to your view - pin details: Yes|yes:";
chomp($choice=<>);
if($choice eq "Yes" || $choice eq "yes"){
	open(FH,"pin_history.log") or die($!);
	while($v=<FH>){
		print $v;
	}
	close(FH);
}
