%host=(); # empty hash

$c=0;
while($c < 3){
	
	print "Enter a alias name:";
	chomp($a=<>);
	print "Enter $a IP-Address:";
	chomp($ip=<>);
	
	$host{$a}=$ip;
 	$c++;
}

 while(($k,$v)=each(%host)){	

	print "$k\t $v\n";
 }
  
