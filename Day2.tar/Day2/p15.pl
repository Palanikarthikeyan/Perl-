
if (scalar(@ARGV) == 0){
	print "Usage:Commandline args is empty\n";
	exit; # exit from script
}
print "@ARGV\n\n";
print "0th index:$ARGV[0]\n";
print "1st index:$ARGV[1]\n";
print "last index:$ARGV[-1]\n";
