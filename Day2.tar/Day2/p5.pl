@fnames=("p1.log","p2.pl","p3.py","p1.txt","pt.sh");

$size=@fnames;
print "A. $fnames[1]\t@fnames\n";
print "Size of an array:$size\n";

$fnames[1]="/var/log/test.log";  # modifcation

print "B. $fnames[1]\t @fnames\n";
$size=@fnames;
print "Size of an array:$size\n";
