
 @emp=("101,raj,sales,pune,1000\n","102,leo,pro,bglore,2000\n","103,anu,HR,noida,3000\n");

 $total=0;
 foreach $var (@emp){
    ($eid,$ename,$edept,$eplace,$ecost)=split(",",$var); # multiple initialization
    print "Emp name:$ename\t Working City:$eplace\n";
    $total=$total+$ecost;
 }
print "-"x50,"\n";
print "\t Sum of Emp's Cost:$total \n";
print "-"x50,"\n";

