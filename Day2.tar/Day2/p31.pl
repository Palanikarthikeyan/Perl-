print "Enter a file name:";
chomp($fname=<>); # Reading from <STDIN> - keyboard

open(FH,"$fname");
while($var=<FH>){ # Reading from <FILE> 
	print($var); # display to monitor
}
close(FH); # close a file Handler
