
$s1="101,raj,sales,pune,1000";

print "A. $s1\t Size:",length($s1),"\n";

@a=split(",",$s1);

$eid=$a[0];
$ename=$a[1];
$edept=$a[2];
$eplace=$a[3];
$ecost=$a[-1];

# (or) using from array to list 

($eid,$ename,$edept,$eplace,$ecost)=@a;

print "Emp name is:$ename\t Working dept is:$edept\n";
