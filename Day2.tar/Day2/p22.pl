
%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

=begin
@r=each(%emp);
print "@r\n";

@r=each(%emp);
print "@r\n";

while(@a=each(%emp)){
	print "@a\n";
}
=cut

while(($k,$v)=each(%emp)){
	print "$k\t $v\n";
}
