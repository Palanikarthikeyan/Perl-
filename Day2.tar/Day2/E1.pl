$pin=1234;
$c=0;

while($c < 3){
	print "Enter a pin number:";
	chomp($p=<>);
	$c++;
	if($p == $pin){
		print "Success - pin is matched - $c\n";
		last; # exit from loop
	}	
}

if($pin != $p){
	print "Sorry your pin is blocked\n";
}
