
open(FH,"emp.csv"); # open a existing file
$var=<FH>; # read  data from <FILE> - not a keyboard - initialize to variable($var)
close(FH); # close a fileHandler 

print($var); # display file content
