@arr=(10,20,30,40,50);

$v1=@arr;

($v2)=@arr;

print "\$v1:$v1\t \$v2:$v2\n";
