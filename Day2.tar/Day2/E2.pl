@pin_history=(); # empty array
$pin=1234;
$c=0;

while($c < 3){
	print "Enter a pin number:";
	chomp($p=<>);
	$c++;
	if($p == $pin){
		print "Success - pin is matched - $c\n";
		push(@pin_history,"success - pin is matched - $c entered on ".`date`);
		last; # exit from loop
	}else{
		push(@pin_history,"failed - input pin number:$p - entered on ".`date`);
	}
}

if($pin != $p){
	print "Sorry your pin is blocked\n";
	push(@pin_history,"Sorry your pin is blocked ".`date`)
}

print "Wish to your view - pin details: Yes|yes:";
chomp($choice=<>);
if($choice eq "Yes" || $choice eq "yes"){
	foreach $var (@pin_history){
		print "$var";
	}
}
