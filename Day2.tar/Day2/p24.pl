
%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

print exists($emp{"ename"}),"\n";
print exists($emp{"Ename"}),"\n";

if(exists($emp{"ename"})){
	print "Yes - key is exists - $emp{ename}\n";
}else{
	print "No - key is not exists\n";
}
	
