@fnames=(); # empty array

@fnames=("p1.pl","index.html");


print("\narray1: @fnames\n");

push(@fnames,"test.log");
push(@fnames,"test.java");

print("\narray2: @fnames\n");

@shells=(); # empty array

@shells=("/bin/sh","/bin/bash");

unshift(@shells,"/usr/bin/perl");

print ("@shells\n");
print("@fnames\n");
