
%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

# keys(%hash) -> @array - list of keys
@a=keys(%emp);

foreach $v (@a){
	print "$v\t $emp{$v}\n";
}
