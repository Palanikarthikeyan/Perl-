@r=grep /log/,(`ls`);
print "@r\n";

print "Total no.of log files:",scalar(@r),"\n";
