@fnames=("p1.log","test.log","p1.c","p.c","p1.c","p1.java");

print "@fnames\n";

$rv=pop(@fnames);

print"$rv\n";
print"@fnames\n";

$r=shift(@fnames);

print "\$r value is:$r\n";
