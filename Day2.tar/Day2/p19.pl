%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

print $emp{"eid"},"\n";
print $emp{"ename"},"\n";
print $emp{"edept"},"\n";

# $hashname{oldkey}=UpdatedValue - hash is mutable - we can change existing value
# ------------------------------

$emp{"edept"}="Production";

print "Updated details:-\n";
print $emp{"edept"},"\n";
print "\n$emp{ename} working place is: $emp{place}\n";
$emp{"place"}="City-1" ; # adding new data to an existing hash
print "\n$emp{ename} working place is: $emp{place}\n";
