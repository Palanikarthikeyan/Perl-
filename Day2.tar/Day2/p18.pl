%h=("K1" => "V1","K2"=>"V2");
print "$h{K1}\t $h{K2}\t $h{K3}\n";
