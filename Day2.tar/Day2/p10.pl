
@sh=("/bin/bash","/bin/sh","/bin/ksh","/bin/tcsh","/bin/zsh");
$c=0;

while($c < scalar(@sh)){
	print $c+1," - $sh[$c]\n";
	$c++;
}
