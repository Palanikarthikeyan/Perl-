%host=(); # empty hash

$c=0;
while($c < 5){
	
	print "Enter a alias name:";
	chomp($a=<>);
	print "Enter $a IP-Address:";
	chomp($ip=<>);
	
	$host{$a}=$ip;
 	$c++;
 }

foreach $k (keys(%host)){
	print "$k\t $host{$k}\n";
}

