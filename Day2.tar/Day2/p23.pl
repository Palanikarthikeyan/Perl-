

%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

print "Total no.of records:",scalar(keys(%emp)),"\n";

delete($emp{'edept'});

print "\n";
print "Total no.of records:",scalar(keys(%emp)),"\n";
