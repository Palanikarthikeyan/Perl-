if(scalar(@ARGV) == 0){
	print "Usage:Commandline argument is empty\n";
	print "$0 <inputfile>\n";
	exit;
}
if(scalar(@ARGV) >1){
	print "Usage:Commnadline args allows single value\n";
	print "$0 <inputfile>\n";
	exit;
}
if("$0" eq $ARGV[0]){
	print "Usage:Sorry your input file and script file both are same\n";
	print "$0 <inputfile>\n";
	exit;
}

if(-e $ARGV[0]){
	print "Yes - file:$ARGV[0] is exists\n";
}else{
	print "Sorry - file:$ARGV[0] is not exists\n";
}
