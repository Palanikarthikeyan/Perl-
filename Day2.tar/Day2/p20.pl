
%emp=("eid" => "e123","ename" => "Mr.Arun","edept" => "sales","ecost" => 12345.25);

print $emp{"eid"},"\n";
print $emp{"ename"},"\n";
print $emp{"edept"},"\n";

# keys(%hash) -> @array - list of keys
print "\n\n";
@a=keys(%emp);
@b=values(%emp);
print "@a\t@b\n";
