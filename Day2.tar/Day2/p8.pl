
 @hosts=(); # empty array

 $size=@hosts;
 print "A. Size of an array:$size\n";

 $c=0;

 while($c < 5){
	print "Enter a hostname:";
	chomp($hostname=<>);
	push(@hosts,$hostname);
	$c=$c+1;
}

 foreach $var (@hosts){
	print "$var\n"
 }
$size=@hosts;
 print "B. Size of an array:$size\n";
