open(WH,">r2.log");
$c=0;
while($c <5){

	print "Enter Some text:";
	$var=<>; # interface to keyboard - reading data from <KB>
	print WH $var; # writing data to FILE
	$c++;

}

close(WH);

