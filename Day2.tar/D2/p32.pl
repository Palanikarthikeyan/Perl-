open(WH,">r1.log");
print WH "Hello\n";
print WH "122,raj,sales,12333\n";
print WH "data\n";
close(WH);
