open(FH,"r1.log");
open(WH,">r3.log");

while($var=<FH>){ # reading data from <FILE>
	print WH $var; # write data to resultfile (r3.log)
}
close(FH);
close(WH);

