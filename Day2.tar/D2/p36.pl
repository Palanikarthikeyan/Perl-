print "Enter a file name:";
chomp($fname=<>);

unless(-f $fname){
	print "Sorry file:$fname is not reg.file\n";
	exit;
}

print "Enter a resultfile:";
chomp($wfname=<>);
if(-e $wfname){
	print "Sorry file:$wfname is already exists\n";
	exit;
}
open(WH,">$wfname");
open(FH,"$fname");
while($var=<FH>){
	print "$var"; #display to monitor
	print WH "$var"; # writing to file
}
close(FH);
close(WH);	
