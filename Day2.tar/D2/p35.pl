print "Enter a file name:";
chomp($fname=<>);

unless(-f $fname){
	print "Sorry file:$fname is not reg.file\n";
	exit;
}

open(FH,"$fname");
while($var=<FH>){
	print "$var"; #display to monitor
}
close(FH);

	
