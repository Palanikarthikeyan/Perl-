open(FH,"invalidFile") || warn($!);
print "This is not part of file content\n";
while($var=<FH>){
	print $var;
}
close(FH);

foreach $v(1,2,3){
	print "Hello\n";
}
