if(scalar(@ARGV) == 0){
	print "Usage:Commandline argument is empty\n";
	print "$0 <result file>\n";
	exit;
}
if(scalar(@ARGV) != 1){
	print "Usage:Commandline argument allows single input file\n";
	print "$0 <result file>\n";
	exit;
}
if(-e $ARGV[0]){
	print "Usage:Result file:$ARGV[0] is already exists\n";
	exit;
}
open(FH,"p2") or die($!);
open(WH,">$ARGV[0]") or die($!);

while(<FH>){
	chomp;
	$_ =~ s/#.*//;
	unless($_ =~ m/^$/){
		print WH "$_\n";
	}
}
close(FH);
close(WH);
$result=`/bin/bash $ARGV[0]`;
open(Wobj,">>result.log")  or die $!;
print Wobj $result;
close(Wobj);
