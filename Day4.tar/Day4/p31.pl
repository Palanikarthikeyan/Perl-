use Data::Dumper;

%netinfo1=(interface =>"eth0",onboot =>"yes",bootproto =>dhcp);

#print $netinfo1{"interface"},"\n"; # will get single value from netinfo1 hash

$netinfo1{"doamin"}="example.com"; # add new data 

$netinfo1{"interface"}="eth1"; # modification

#print Dumper(%netinfo1);
=begin
%netinfo2=(K1 =>{"interface" =>["eth0"],"onboot" =>["Yes","No"]});

print $netinfo2{K1}{interface}[0],"\n";
print $netinfo2{K1}{onboot}[0],"\n";
print Dumper(%netinfo2);
=cut
$r={interface =>["eth0"],onboot =>["Yes","no"],bootproto => [dhcp,static]};

print $$r{"interface"}[0],"\n";
print Dumper($r),"\n";
=cut
$r={interface =>{interface =>["eth0"]},onboot =>{onboot =>["yes","no"]}};
print "=> ",$$r{interface}{interface}[0],"\n";
print Dumper($r),"\n";
