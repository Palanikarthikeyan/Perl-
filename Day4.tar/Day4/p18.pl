
use Data::Dumper;

@a=({K1=>"V1",K2=>"V2",K3=>"V3"},{app =>"flask",port =>5000});

print Dumper(@a);

$r1=$a[0];

%h=%$r1;
foreach(keys(%h)){
	print "$_\t$h{$_}\n";
}
