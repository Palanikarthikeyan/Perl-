END{
package One;
print "This is block-1 code\n";
}
package Two;
sub display{
	print "This is display block\n";
}
display();
BEGIN{
package Three;
print "This is ",__PACKAGE__," name\n";
}
package Four;
print "This is 4th block code\n";
BEGIN{
package Five;
print "This is 5th block code\n";
}
END{
package six;
print "This is 6th block\n";
}
BEGIN{
package sevan;
print "This is 7th block\n";
}
