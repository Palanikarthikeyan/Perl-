sub report{
	print "system generated report details:-\n";
}
%myenv=(sh =>"/bin/bash");
@ports=(5000,5090,3000);
