use Data::Dumper;
$r1=sub{
	print "Hello\n";
	print "List of files\n";
	print "@_\n";
	print "Total no.of args:",scalar(@_),"\n";
};

%h=(K1=>$r1,K2=>["D1","D2",$r1]);
#print Dumper(\%h);

$r=$h{K1};
&$r;
$r=$h{K2}[-1];
&$r; 

