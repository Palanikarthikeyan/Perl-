
use Data::Dumper;

@a=({K1=>"V1",K2=>"V2",K3=>"V3"},{app =>"flask",port =>5000});
  #-----------------------------|--------------------------
  #         0th index		|	1st index
  # 

print $a[0]{"K1"},"\n";
print $a[0]->{"K1"},"\n";
print $a[1]{"app"},"\n";
