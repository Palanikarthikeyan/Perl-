use Data::Dumper;
@a=();

push(@a,"D1"); # Scalar - single
push(@a,["D2","D3","D4"]); # Array of Array
push(@a,{"K1"=>"V1","K2"=>"V2"}); # Array of Hash
print Dumper(@a);
print("\n");
%h=();

$h{"Key1"}="V1"; # Scalar - single
$h{"Key2"}=[10,20,30]; # Hash of Array

print Dumper(%h);

