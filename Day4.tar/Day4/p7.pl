$var="10:01:02 up 44 min,  2 users,  load average: 0.07, 0.15, 0.11";
$var =~ tr /a-z/A-Z/;
print "$var\n";

$var="10:01:02 up 44 min,  2 users,  load average: 0.07, 0.15, 0.11";
$var =~ tr /0-9/-/;
print "$var\n";

$var="10:01:02 up 44 min,  2 users,  load average: 0.07, 0.15, 0.11";
$var =~ tr /" "/-/;
print "$var\n";
