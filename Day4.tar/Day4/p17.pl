use Data::Dumper;
@a=("D1","D2","D3");

%h=(K1=>"V1",K2=>"V2");

print Dumper(\@a);
print Dumper(\%h);
