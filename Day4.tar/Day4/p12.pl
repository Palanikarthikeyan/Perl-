
@A=("D1","D2","D3");

@B=(101,102,103,104,105);

@C=("Data-1","Data-2",@A,"Data-3",@B,"Data-4","Data-5");

print "@C\n";
print "Size of \@C:",scalar(@C),"\n";
