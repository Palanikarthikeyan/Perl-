package Fax;
sub display{
	print "This is ",__PACKAGE__," package file\n";
	print "display - fax number and other details\n";
}
%myenv=(sh => "/bin/bash", app => "testApp");
$var=120;
1;
