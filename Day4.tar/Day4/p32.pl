
$r1=sub{
	print "Hello\n";
	print "List of files\n";
	print "@_\n";
	print "Total no.of args:",scalar(@_),"\n";
};
print ref($r1),"\n";
&$r1;

&$r1(10,20,30,40);
