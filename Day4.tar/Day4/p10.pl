opendir(DH,".") or die($!);
@a=readdir(DH);
closedir(DH);
print "@a\n";
