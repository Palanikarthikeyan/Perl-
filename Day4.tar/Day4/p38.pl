sub f1{
	print "Hello\n";
}
fx();
