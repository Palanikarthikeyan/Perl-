opendir(DH,".") or die($!);
@a=readdir(DH);
closedir(DH);

@r=grep(/py$|pl$/,@a);
foreach(@r){
	print "$_\n";
}
print "\n";
opendir(DH,".") or die($!);
foreach(grep(/py$|pl$/,readdir(DH))){
	print "$_\n";
}
