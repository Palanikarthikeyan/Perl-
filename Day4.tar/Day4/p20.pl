 use Data::Dumper;
 @a=(["Server1","Server2","Server3"],{"IP"=>"10.20.30.40","prefix" =>24,"hostname" =>"example.com"});

 # display 
 # ------- 
 #   |->Server2
 #   |->10.20.30.40
 #   |->example.com
 #
 #  modify 
 #   |->Server3 => OL7
 #   |->10.20.30.40 => 127.0.0.1

 # use Data::Dumper - Dumper() - display array 

 print "$a[0][1]\t $a[1]{IP}\t $a[1]{hostname}\n";

print Dumper(@a);
$a[0][-1]="OL7";
$a[1]{'IP'}="127.0.0.1";

print "\nUpdated Array:-\n";
print Dumper(@a);

