open(FH,"emp.csv");
=begin
while(<FH>){
	print "$_";
}
close(FH);
=cut

$r1=\*FH;
print $r1,"\t",ref($r1),"\n";

sleep 3;

print <$r1>;

