 use Data::Dumper;

 %emp=(eid =>['E123','E345','E213'],ename =>['Mr.ABC','Mr.X','Ms.Y'],edept=>['admin','prod','HR']);
  
print Dumper(%emp);
print "\n";
print "$emp{eid}[0]\t$emp{ename}[0]\t$emp{edept}[0]\n";
$emp{edept}[0]="QA"; # modification 
print "$emp{eid}[0]\t$emp{ename}[0]\t$emp{edept}[0]\n";

print Dumper(%emp);
print "\n";
