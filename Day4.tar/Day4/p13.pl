use Data::Dumper;

@a=("D1","D2","D3");

$r1=\@a;

print Dumper(@a);
print "\n";
print Dumper($r1);

print "\n";

$b=["D1","D2","D3"];
print "$b\n";
print ref($b),"\n";

@c=@$b;
print "@c\n";
