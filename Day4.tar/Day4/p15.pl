use Data::Dumper;

    #
    #    0       1      2        0      1     2
@aoa=(["unix","Linux","sunos"],["ash","bash","csh"]);
#     --------0th------------ |-------1st---------
#
print "A.Size of \@aoa is: ",scalar(@aoa),"\n";

=begin
print Dumper(@aoa);

print $aoa[0],"\n";
$r1=$aoa[0];
print "@$r1\n";
=cut

#print $aoa[0]; # ARRAY(0x1235)

print $aoa[0][0],"\n";    # procedure style
print $aoa[0]->[0],"\n";  # oops style

print $aoa[0][1],"\n";
print $aoa[1][1],"\n";
