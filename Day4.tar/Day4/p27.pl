use Data::Dumper;

$a=[["D1","D2","D3"],{K1=>"V1",K2=>"V2"}];

print $a,"\n";
print $$a[0][0],"\n";
print $$a[0][1],"\n";
print $$a[1],"\n"; # HASH(0x333)
print $$a[1]{"K1"},"\n";
=begin
%h=$$a[1];
foreach(keys(%h)){
	print "$_\t$h{$_}\n";
}
=cut
