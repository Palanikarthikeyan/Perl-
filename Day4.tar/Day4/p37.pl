sub f1{
	print "This is f1 block from ",__PACKAGE__," package \n";
}
f1(); 

package Fax;
sub f1{
	print "This is f1 block from ",__PACKAGE__," package \n";
}
f1(); 
main::f1(); # from Fax package - we are calling main package - f1() function
fx(); # invalid Call
