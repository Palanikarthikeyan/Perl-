
=begin

int a=10;  a | 10    | 0x1000
int *p;    p | GB    | 0x1002
p=&a;      p |0x1000 |0x1002
p=20; Error 
*p=20; OK *(&a) a | 20 |0x1000
print a -> 20  
=cut

$a=10;
$r1=\$a;
# $r1=20; Error

print "$a\n";
$$r1=20; # OK
print "$a\n";
