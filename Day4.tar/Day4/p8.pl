$v="sample peeerl script perl5 script examples";
$v =~ tr /e/E/;
print("$v\n");

$v="sample peeeerl script perl5 script examples";
$v =~ tr /e/E/s;
print("$v\n");

print("\n");
$v="perl5 and python3 programming course";
$v =~ tr /p/P/;
print($v,"\n");
$v="perl5 and python3 programming course";
$v =~ tr /p/P/c;
print($v,"\n");

$v="perl5 and python3 programming course";
$v =~ tr /0-9/-/c;
print($v,"\n");

