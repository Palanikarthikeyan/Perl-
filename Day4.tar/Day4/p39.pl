$var=100;

package Fax;
$cost=500;
$name="root";
package Mail;
$email="user\@hostname.com";

package Test;
print $main::var,"\n";
print $Fax::cost,"\n";
if($Fax::name eq "root"){
	print "Login is success\n";
	print "Email:$Mail::email\n";
}
print "This is from ",__PACKAGE__," package\n";

package demo;
print "This is from ",__PACKAGE__," package\n";

