print("ONE\n");
print("TWO\n");
print("THREE\n");
abcd;
print("END OF THE LINE\n");
