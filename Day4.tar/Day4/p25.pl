   use Data::Dumper;
   %h=(K1 =>{K1 =>100,K2 =>200,K3 =>300},K2 =>{DB1 =>oracle,DB2=>sqlite3},K3=>{K1 =>10,K2=>20,K3=>30});
   print Dumper(%h);
