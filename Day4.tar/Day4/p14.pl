use Data::Dumper;
@a=("D1","D2","D3",["D4","D5","D6"],"D7","D8");

print Dumper(@a);


