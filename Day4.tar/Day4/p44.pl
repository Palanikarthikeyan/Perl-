require "/home/apelix/p43.pl";
foreach(keys(%myenv)){
	print "$_\t $myenv{$_}\n";
}

sub report{
	print "vmstat status report\n";
	system("vmstat");
}
report();
