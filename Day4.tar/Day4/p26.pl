use Data::Dumper;
@a=([],{});

%h=(K1=>[],K2=>{});

print Dumper(\%h);
=begin
$VAR1 = [
          [],
          {}
        ];
$VAR1 = {
          'K2' => {},
          'K1' => []
        };
=cut

