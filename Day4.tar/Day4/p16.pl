@a=(); # empty array

push(@a,"itemA");
push(@a,["D1","D2","D3","D4"]); # Array of Array

print "@a\n";

print "$a[1][0]\n";
print "$a[1][1]\n";
print "$a[1][-1]\n";

$a[1][1]=1234;

print "-->$a[1][1]\n";
use Data::Dumper;
print Dumper(@a);
