$s1="root:x:bin:bash";
@r1=split(":",$s1);

print "@r1\n";

$s2="root:x-bin,bash";
@r2=split("[^a-zA-Z0-9\s]",$s2);
print "@r2\n";
