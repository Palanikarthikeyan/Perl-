use Data::Dumper;
$r={ 
K1 =>"V1",
K2 => [DB1,DB2,DB3,DB4],
K3 => {app =>flask,port =>5000}
};
print "$r\n";
sleep 3;
print Dumper($r);

