use Fax;
Fax::display();
print "$Fax::myenv{sh}\n";
