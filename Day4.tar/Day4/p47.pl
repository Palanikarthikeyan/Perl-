use lib "/home/apelix/L1";
use Fax;
Fax::display();
print "$Fax::myenv{sh}\n";
