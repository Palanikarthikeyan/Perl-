$var="root:x:bin:bash";

$var =~ s/:/-/g;
print("$var\n");


$var="root:x:bin:bash";

$var =~ tr /:/-/; #  character replacement 
print("$var\n");

$var =~ s/bash/ksh/; # word/string replacement 
print "$var\n";

$var="root:x:bin:bash";

$var =~ tr /bash/ksh/; # character replacement 
print "$var\n";
