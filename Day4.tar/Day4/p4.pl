sub f1{
	print "This is f1 block\n";
}
sub f2{
	print "This is f2 block\n";
}
sub fdisplay{
	print "This is display block\n";
}
sub AUTOLOAD{
	print "undefined functionCall $AUTOLOAD invoked at ",`date`;
	
}
print "This is main section code\n";
f1();
f2();
Fdisplay();
for $v (10,20,30){
	print "\$v value is:$v\n";
}
print "Exit from $0 file\n";

