$var=100;
@s=(OL5,OL6,OL7);
%h=(K1=>"V1");
sub display{
	print "display - list of mounted file system details:-\n";
	system("df -Th");
}
print "\@s:@s\n";
display();
print "This is ",__PACKAGE__," package\n";
package Fax;
sub display{
	print "display - fax details\n";
	print "This is ",__PACKAGE__," package\n";
}
display();
package Mail;
@s=("httpd","apache2","crond");
print "\@s:@s\n";
package main;
display(); # calling main package function
package Fax;
display(); # calling Fax package function
