open(FH,"D:\\inventory.txt") or die($!);

while(<FH>){
	if($_ =~ "^[0-9].*"){
	  @a=split(":",$_);
	  @b=split(",",$a[1]);
	  $t=0;
	  foreach $v ((@b)){
		$t=$t+$v;
	  }
		print "item code:$a[0]\t total sales count:$t\n";
	}
}

close(FH);