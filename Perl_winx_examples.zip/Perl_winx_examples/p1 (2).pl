print "Hello\n";
print "welcome";