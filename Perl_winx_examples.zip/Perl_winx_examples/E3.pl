open(FH,"IP.txt") or die($!);
while(<FH>){
        if(m/bash/){ # $_ =~ /bash/
		@a=split("[^a-zA-Z0-9\s]",$_);
		print "$.\t$a[1]\t$a[0]\t$a[-1]\n";
	}
}
close(FH);