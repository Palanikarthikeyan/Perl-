package App;

sub new{
($class,$s,$p,$v,$u)=@_;
$app_info={service=>,port=>0,version=>0.0,user=>undef};

$app_info->{service}=$s;
$app_info->{port}=$p;
$app_info->{version}=$v;
$app_info->{user}=$u;

print "initialization is done!\n";
return bless($app_info,$class);
}

sub display{
  open(WH,">>appinfo.log") or die $!;
  ($r1)=@_;
  print "Service name:$r1->{service}\n";
  print "Port number:$r1->{port}\n";
  print "Version:$r1->{version}\n";
  print "User:$r1->{user}\n";
  print "-"x50,"\n";
  print WH "Service name:$r1->{service}\n";
  print WH "Port number:$r1->{port}\n";
  print WH "Version:$r1->{version}\n";
  print WH "User:$r1->{user}\n";
  print WH "-"x50,"\n";
  close(WH); 
}

sub update{
	($r1)=@_;
	print "Enter a updated service name:";
	chomp($s=<>);
	print "Enter $s port number:";
	chomp($p=<>);
	$r1->{service}=$s;
	$r1->{port}=$p;
	print("Updated ..\n");
}


package main;

$obj1=App->new("flask",5000,1.0,"admin");
$obj1->display();
$obj1->update();
print("Updated details:-\n");
$obj1->display();

$obj2=App->new("prometheus",9090,1.1,"student");
$obj2->display();