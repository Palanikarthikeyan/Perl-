package box;
  sub init{
	%h=(eid =>'',ename =>''); # print Dumper(%h); Vs print Dumper(\%h);
	print("This is constructor block\n");
	return bless(\%h);
  sub f1{
	print "f1 block - @_\n";
  }

  sub f2{
	print "f2 block - @_\n";
  }
}

$obj1=box::init();
$obj1->f1(); # non-constructor
$obj1->f2(); # non-constructor

print("\n");

$obj2=box::init();
$obj2->f1(); # non-constructor
$obj2->f2(); # non-constructor
