BEGIN{
push(@INC,"C:\\Users\\Karthikeyan\\Desktop");
}
use App;

$obj1=App->new("ntpd",80,2.3,"root");
$obj1->display();
$obj1->update();
print("Updated details:-\n");
$obj1->display();

$obj2=App->new("alert",9093,1.2,"kumar");
$obj2->display();